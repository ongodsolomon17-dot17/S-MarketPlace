"use strict";
applyThemePreference();
/* ============================================================================
   main.js — wires buttons to the functions in the other files, then starts the app.

   Instead of attaching a listener to every button (cards are created on the fly),
   one listener on the whole page checks which button was clicked, using the
   data-… attributes written in the HTML.
   ============================================================================ */

document.addEventListener("click", async event => {
  const target = event.target;
  const closest = selector => target.closest(selector);

  if (handleListToolClick(target)) return;       // search / sort controls on the trader lists

  if (closest("[data-finance-category]")) { selectFinanceBalance(closest("[data-finance-category]").dataset.financeCategory); return; }
  if (closest("[data-toggle-balance]")) { toggleFinanceBalanceVisibility(); return; }
  if (closest("[data-finance-settings]")) {
    showPage("settings");
    window.setTimeout(() => document.getElementById("payout-form")?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
    return;
  }
  if (closest("[data-finance-notifications-all]")) {
    if (!currentUser || currentUser.role !== "trader") return;
    showPage("trader-notifications");
    return;
  }

  /* ---- page navigation ---- */
  const navLink = closest("[data-page-link]");
  if (navLink) { event.preventDefault(); showPage(navLink.dataset.pageLink); return; }
  if (closest("[data-open-subscription]")) { await openTraderSubscriptionModal(); return; }
  if (closest("[data-close-subscription-modal]")) { closeTraderSubscriptionModal(); return; }
  if (closest("[data-back]")) { closeProduct(); return; }
  if (target.id === "header-account-button" || closest("#header-account-button")) { openAccountArea(); return; }

  /* ---- cart buttons come BEFORE "open product" because the + button sits on top of the picture ---- */
  const addButton = closest("[data-add-to-cart]");
  if (addButton) { if (!addButton.disabled) await addToCart(addButton.dataset.addToCart); return; }
  const addDealButton = closest("[data-add-deal-to-cart]");
  if (addDealButton) { if (!addDealButton.disabled) await addDealToCart(addDealButton.dataset.addDealToCart); return; }
  const storeButton = closest("[data-open-store]");
  if (storeButton) { await openStore(storeButton.dataset.openStore); return; }
  const productOpener = closest("[data-open-product]");
  if (productOpener) { await openProduct(productOpener.dataset.openProduct); return; }

  const quantityButton = closest("[data-cart-quantity]");
  if (quantityButton) { await changeCartQuantity(quantityButton.dataset.cartQuantity, Number(quantityButton.dataset.quantity)); return; }
  const removeButton = closest("[data-remove-cart]");
  if (removeButton) { await removeCartItem(removeButton.dataset.removeCart); return; }
  if (target.id === "checkout-button") {
    if (!currentUser || currentUser.role !== "buyer") {
      window.checkoutPending = true;
      openAuth("buyer");
      if (currentUser?.role === "trader") document.getElementById("auth-feedback").textContent = "You're signed in as a trader. Please use a buyer account to check out.";
    } else {
      await openCheckout();
    }
    return;
  }
  if (closest("[data-close-checkout]")) { document.getElementById("checkout-overlay").hidden = true; return; }

  /* ---- home screen: chips, search, refresh, load more ---- */
  const chip = closest(".chip");
  if (chip) { selectCategory(chip.dataset.category); return; }
  if (target.id === "search-button") { runSearch(); return; }
  if (target.id === "refresh-feed-button") { refreshFeed(); return; }
  if (target.id === "load-more-button") { target.disabled = true; await loadHome(true); target.disabled = false; return; }
  if (closest("[data-scroll-to]")) { document.getElementById(closest("[data-scroll-to]").dataset.scrollTo)?.scrollIntoView({ behavior: "smooth" }); return; }

  /* ---- sign up / log in ---- */
  const roleButton = closest("[data-auth-role]");
  if (roleButton) { showAuthForm("signup", roleButton.dataset.authRole); return; }
  const authOpener = closest("[data-open-auth]");
  if (authOpener) { openAuth(authOpener.dataset.openAuth); return; }
  if (closest("[data-close-auth]")) { closeAuth(); return; }
  if (target.id === "choice-login") { showAuthForm("login", "buyer"); return; }
  if (target.id === "signup-tab") { showAuthForm("signup", activeAuthRole); return; }
  if (target.id === "login-tab") { showAuthForm("login", activeAuthRole); return; }
  if (target.id === "back-to-roles") {
    document.getElementById("auth-form-wrap").hidden = true;
    document.getElementById("role-choices").hidden = false;
    document.getElementById("auth-title").textContent = "How would you like to continue?";
    return;
  }
  if (closest("[data-logout]")) { await logout(); return; }

  /* ---- trader tools: products ---- */
  if (closest("[data-open-create-panel]")) { openTraderCreatePanel(); return; }
  if (closest("[data-close-trader-create]")) { closeTraderCreatePanel(); return; }
  if (closest("[data-reload-owned-products]")) { await loadOwnedProducts(); return; }
  if (closest("[data-open-product-editor]")) { await openProductEditor(); return; }
  const editButton = closest("[data-edit-product]");
  if (editButton) { closeOwnedProductDetail(); await openProductEditor(ownedProducts[editButton.dataset.editProduct]); return; }
  const viewOwned = closest("[data-view-owned-product]");
  if (viewOwned) { openOwnedProductDetail(viewOwned.dataset.viewOwnedProduct); return; }
  if (closest("[data-close-owned-product]")) { closeOwnedProductDetail(); return; }
  if (closest("[data-close-product-editor]")) { closeProductEditor(); return; }
  if (target.id === "pe-delete") { await deleteEditingProduct(); return; }
  if (target.id === "pe-pause") { await togglePauseEditing(); return; }
  const restoreButton = closest("[data-restore-product]");
  if (restoreButton) { await restoreProduct(restoreButton.dataset.restoreProduct); return; }
  
  if (closest("[data-subscription-checkout]")) {
    await startTraderSubscriptionCheckout();
    return;
  }

  if (closest("[data-subscription-renewal-off]")) {
    await disableTraderSubscriptionAutoRenew();
    return;
  }
  const updateLine = closest("[data-update-item]");
  if (updateLine) { await updateOrderLine(updateLine.dataset.updateItem); return; }

  /* ---- Fast Finger ---- */
  if (closest("[data-open-deal-editor]")) { await openDealEditor(); return; }
  if (closest("[data-close-deal-editor]")) { closeDealEditor(); return; }
  const soldButton = closest("[data-deal-sold]");
  if (soldButton) { await markDealSold(soldButton.dataset.dealSold); return; }
  const deleteDealButton = closest("[data-deal-delete]");
  if (deleteDealButton) { await deleteDeal(deleteDealButton.dataset.dealDelete); return; }
  const description = closest("[data-toggle-description]");
  if (description) { description.classList.toggle("is-open"); return; }   // tap a deal's text to read all of it

  /* ---- delivery confirmation (buyer) ---- */
  const openDelivery = closest("[data-open-delivery]");
  if (openDelivery) { openDeliverySheet(openDelivery.dataset.openDelivery); return; }
  if (closest("[data-close-delivery]")) { closeDeliverySheet(); return; }
  const startScanButton = closest("[data-start-scan]");
  if (startScanButton) { await startScan(startScanButton.dataset.startScan); return; }
  if (closest("[data-stop-scan]")) { stopScan(); return; }
  const codeButton = closest("[data-submit-code]");
  if (codeButton) { submitManualCode(codeButton.dataset.submitCode); return; }
  const receivedButton = closest("[data-confirm-received]");
  if (receivedButton) { receivedButton.disabled = true; await confirmReceived(receivedButton.dataset.confirmReceived); return; }
  const disputeButton = closest("[data-open-dispute]");
  if (disputeButton) { openDispute(disputeButton.dataset.openDispute); return; }
  if (closest("[data-close-dispute]")) { closeDispute(); return; }

  /* ---- delivery QR (trader) ---- */
  const qrButton = closest("[data-delivery-qr]");
  if (qrButton) { await openDeliveryQR(qrButton.dataset.deliveryQr); return; }
  if (closest("[data-close-qr]")) { closeDeliveryQR(); return; }
  if (closest("[data-qr-share]")) { await shareDeliveryQR(); return; }
  if (closest("[data-qr-download]")) { await downloadDeliveryQR(); return; }
  if (closest("[data-qr-regenerate]")) { if (confirm("Make a new code? The old QR will stop working.")) await openDeliveryQR(qrState.itemId, true); return; }

  /* ---- money and notifications ---- */
  if (closest("[data-request-payout]")) { await requestPayout(); return; }
  if (closest("[data-mark-notifications-read]")) { await markNotificationsRead(); return; }



  /* ---- admin ---- */
  if (closest("[data-admin-mfa-start]")) {
    await startAdminMfa();
    return;
  }

  if (closest("[data-admin-mfa-confirm]")) {
    await confirmAdminMfa();
    return;
  }
  
  if (closest("[data-admin-mfa-recovery]")) {
    await createAdminMfaRecoveryCodes();
    return;
  }

  const savePlanButton = closest("[data-admin-plan-save]");
  if (savePlanButton) {
    await saveAdminSubscriptionPlan(savePlanButton.dataset.adminPlanSave);
    return;
  }
  const resolveButton = closest("[data-admin-resolve]");
  if (resolveButton) { await resolveDispute(resolveButton.dataset.adminResolve, resolveButton.dataset.decision); return; }

  const paidButton = closest("[data-admin-paid]");
  if (paidButton) { await markPayoutPaid(paidButton.dataset.adminPaid); return; }

  const rejectButton = closest("[data-admin-reject]");
  if (rejectButton) { await rejectPayout(rejectButton.dataset.adminReject); return; }



  /* ---- shops, followers, chat, ratings ---- */
  const followButton = closest("[data-follow-shop]");
  if (followButton) { await toggleFollowShop(followButton); return; }
  const messageButton = closest("[data-message-trader]");
  if (messageButton) { openChat(messageButton.dataset.messageTrader); return; }
  const shareButton = closest("[data-share-shop]");
  if (shareButton) { await shareShop(shareButton.dataset.shareShop); return; }
  if (closest("[data-open-my-store]")) { openMyStore(); return; }
  if (closest("[data-open-chat]")) { openChat(); return; }
  const community = closest("[data-community]");
  if (community) {
    if (community.dataset.community === "followers") openMyStore();
    else showToast(traderSummary ? `You follow ${traderSummary.following} shop${traderSummary.following === 1 ? "" : "s"}.` : "Loading…");
    return;
  }
  const rateButton = closest("[data-open-rating]");
  if (rateButton) { openRating(rateButton.dataset.openRating); return; }
  if (closest("[data-close-rating]")) { closeRating(); return; }
  const star = closest("[data-star]");
  if (star) { ratingStars = Number(star.dataset.star); paintRatingStars(); return; }
  if (closest("[data-submit-rating]")) { await submitRating(); return; }

  /* ---- admin: verify traders ---- */
  const verifyButton = closest("[data-admin-verify]");
  if (verifyButton) { verifyButton.disabled = true; await setTraderVerified(verifyButton.dataset.adminVerify, verifyButton.dataset.verified === "true"); return; }
  if (closest("[data-admin-trader-search]")) { await loadAdminTraders(); return; }

  /* ---- buyer orders ---- */
  const payButton = closest("[data-pay-order]");
  if (payButton) { payButton.disabled = true; await payOrder(payButton.dataset.payOrder); return; }
  const cancelButton = closest("[data-cancel-order]");
  if (cancelButton) { await cancelOrder(cancelButton.dataset.cancelOrder); return; }
});

/* Keyboard: Enter or Space on a focused product picture opens it (it is a role="button" div). */
document.addEventListener("keydown", event => {
  const opener = event.target.closest?.("[data-open-product][role='button']");
  if (opener && (event.key === "Enter" || event.key === " ")) { event.preventDefault(); openProduct(opener.dataset.openProduct); }
});

/* Search boxes on the trader lists filter as you type. */
document.addEventListener("input", event => {
  if (event.target.matches?.("[data-list-search]")) handleListSearchInput(event.target);
});

/* Enter on a product picture/name in the trader lists opens its details. */
document.addEventListener("keydown", event => {
  const opener = event.target.closest?.("[data-view-owned-product][role='button']");
  if (opener && (event.key === "Enter" || event.key === " ")) { event.preventDefault(); openOwnedProductDetail(opener.dataset.viewOwnedProduct); }
  if (event.key === "Enter" && event.target.id === "admin-trader-search") { event.preventDefault(); loadAdminTraders(); }
  if (event.key === "Escape") { closeSortMenus(); closeOwnedProductDetail(); closeRating(); }
});

/* Search box: Enter searches. */
document.getElementById("market-search").addEventListener("keydown", event => {
  if (event.key === "Enter") { event.preventDefault(); runSearch(); }
});

/* Forms. */
document.getElementById("auth-form").addEventListener("submit", submitAuth);
document.getElementById("product-form").addEventListener("submit", saveProduct);
document.getElementById("deal-form").addEventListener("submit", saveDeal);
document.getElementById("dispute-form").addEventListener("submit", submitDispute);
document.getElementById("checkout-form").addEventListener("submit", submitCheckout);
document.getElementById("pe-category").addEventListener("change", toggleCustomCategory);
document.getElementById("pe-slash-toggle").addEventListener("change", togglePriceSlash);

/* Theme choices in Settings apply immediately and persist on this device. */
document.addEventListener("change", event => {
  const choice = event.target.closest?.("[data-theme-choice]");
  if (choice && choice.checked) {
    saveThemePreference(choice.value);
    showToast((choice.value === "light" ? "Light" : "Dark") + " theme selected.");
  }
});
/* Price-slash inputs (product pop-up and deal pop-up): update the "= new price" line as the trader types. */
document.addEventListener("input", event => {
  if (event.target.classList.contains("slash-input")) refreshSlashPreview(event.target.dataset.slash);
});

/* If the browser restores this page from its back/forward cache after Paystack, reload so nothing is stuck. */
window.addEventListener("pageshow", event => { if (event.persisted) window.location.reload(); });

/* ----------------------------------------------------------------------------
   Start-up
   ---------------------------------------------------------------------------- */
(async function initializeApp() {
  // 1. Who is signed in? (An invalid or expired token is thrown away.)
  try {
    const result = await apiRequest("/api/me");
    currentUser = result.user;
    if (!currentUser) localStorage.removeItem(TOKEN_KEY);
  } catch (_) { /* guests can browse without signing in */ }
  updateHeaderAccount();
  renderAccount();

  // 2. Did Paystack just send the buyer back with a payment reference?
  const params = new URLSearchParams(window.location.search);
  const reference = params.get("reference") || params.get("trxref");
  if (reference) {
    window.history.replaceState({}, "", window.location.pathname);
    await confirmPayment(reference);
  }

  // 3. Fill the home screen (the feed, category chips, trader shops) and the cart badge.
  const startupTasks = [refreshCartCount(), loadCategoryChips(), loadTraders(), loadHome()];
  if (currentUser && currentUser.role === "trader") startupTasks.push(loadTraderSubscription());
  await Promise.all(startupTasks);

  // 4. A shared shop link (…/?shop=username) opens that shop.
  const sharedShop = params.get("shop");
  if (sharedShop) {
    window.history.replaceState({}, "", window.location.pathname);
    await openStore(sharedShop);
  }
})();
